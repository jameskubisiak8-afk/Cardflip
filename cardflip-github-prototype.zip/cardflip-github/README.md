# CardFlip Scout — GitHub/Netlify prototype

A mobile-friendly football-card flipping calculator and watchlist. **No automatic purchasing, market-price API, eBay OAuth, or selling is implemented.**

## Deploy on Netlify
1. Upload `index.html`, `README.md`, and `netlify.toml` to the root of your GitHub repository.
2. In Netlify, choose **Add new project → Import an existing project → GitHub**.
3. Select the repository. No build command is needed; publish directory is `.`.
4. Deploy and open the resulting URL on your iPad.

## Data
Watchlist entries are stored only in your browser's localStorage and can be exported as CSV. Clearing browser data removes the watchlist. No credentials are required or collected.

## Next production steps
Add Supabase Auth + RLS for persistent storage, server-side eBay OAuth, approved eBay search/listing API calls, authorized market-price data, and a purchase approval flow. Do not put eBay client secrets or Supabase service-role keys into frontend files.
